readonly = ["read_wrap.h", "secure_move.h", "shred.h", "utils.h", 
			"utils.c", "Makefile"]
writable = ["secure_move.c", "shred.c", "read_wrap.c", 
			"files/blank.txt", "files/final.orig.txt", "files/final.txt",
			"files/final_sol.txt"]
shared = readonly + writable
individual = True